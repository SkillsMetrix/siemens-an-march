import { Component } from '@angular/core';

@Component({
  selector: 'app-formdemo',
  templateUrl: './formdemo.component.html',
  styleUrl: './formdemo.component.css'
})
export class FormdemoComponent {

}
