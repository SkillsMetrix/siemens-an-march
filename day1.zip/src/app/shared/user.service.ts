import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  loadUsers(): any[] {
    return ['admin', 'manager', 'qa', 'CA']
  }

 
}
