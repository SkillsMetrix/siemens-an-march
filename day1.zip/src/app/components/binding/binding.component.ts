import { Component } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrl: './binding.component.css'
})
export class BindingComponent {


  people: any[] = [

    {
      "name": "admin",
      "country": "USA"
    },
    {
      "name": "QA",
      "country": "INDIA"
    },
    {
      "name": "Manager",
      "country": "UK"
    }
  ]

  getColor(country: string) {
    switch (country) {
      case 'UK':
        return 'green'
      case 'INDIA':
        return 'blue'
      case 'USA':
        return 'purple'
      default:
        return country
    }
  }
}
