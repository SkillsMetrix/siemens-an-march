import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  uname='Ahmed'
  image='https://newprofilepic.photo-cdn.net//assets/images/article/profile.jpg?90af0c8'

  addUser(){
    console.log('user added');
    
  }
  shoppingCart=['oil']
}
