import { Component } from '@angular/core';
import { UserService } from '../../shared/user.service';

@Component({
  selector: 'app-mainapp',
  templateUrl: './mainapp.component.html',
  styleUrl: './mainapp.component.css'
})
export class MainappComponent {
  constructor(private us: UserService) {

    this.usersData = this.us.loadUsers()

  }

  usersData: any = []

}
